#__init__.py
#XObject + GlobalData v3.1.3 Starlight (08.2021)

# from xo import *
from .gd import *

# meet xo. your new friend
# :) enjoy

### XObject + GlobalData - Version 3.2.6 - Startlight✨
# _xObject + Global Data_ <br>Use Python Like You Never Have Before ! <br>
### _Easy Acces To:_
## 🔔 Events and Triggers <br> 💛 Realtime MultiProcessing <br> 🏃 Instant Dynamic DB <br> 📁 Filesytem & Web Watchdog <br> 🌐 Sockets, MQTT, P2P, API Server <br> ⚡ Supports Fast Prototyping To Large Scale Systems <br><br>

xo-gd
===============================

version number: 3.2.6 ChatParadise
author: Tami Bar

Overview
--------

Use Python Like You Never Have Before, Easy Acces To: Events and Triggers, Realtime MultiProcessing, Instant Dynamic DB, Filesytem & Web Watchdog, Sockets, MQTT, P2P, API Server, Supports Fast Prototyping To Large Scale Systems

Installation / Usage
--------------------

To install use pip:

    $ pip install xo-gd

Or clone the repo:

    $ git clone https://github.com/fire17/xo-gd.git
    $ python setup.py install


To Use xObject:
In python run:
    $ from xo import *
or:
    $ import xo ; xo = xo.ok()


Contributing
------------

TBD

Example
-------

TBD

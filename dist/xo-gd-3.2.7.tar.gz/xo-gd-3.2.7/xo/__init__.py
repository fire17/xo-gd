#__init__.py
#XObject + GlobalData v3.1.3 Starlight (08.2021)

# from xo import *
# print()
# print(" ::: Please use ")
# print(" :::    from xo import *")
# print(" ::: or        ")
# print(" :::    import xo; xo = ok()")
# print()

print("LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL")
from .gd import *
# xo = xo.ok()


# meet xo. your new friend
# :) enjoy

#__init__.py
#XObject + GlobalData v3.1.3 Starlight (08.2021)

# from xo import *
print()
print(" ::: imported xo successfully ")
from .gd import *
xo = xo.ok()


# meet xo. your new friend
# :) enjoy

#__init__.py
#XObject + GlobalData v3.1.3 Starlight (08.2021)

# from xo import *
from xo.gd import *

# meet xo. your new friend
# :) enjoy

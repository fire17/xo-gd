XObject + GlobalData
===============================

version number: 3.1.3
author: Tami Bar

Overview
--------

Use Python Like You Never Have Before, Easy Acces To: Events and Triggers, Realtime MultiProcessing, Instant Dynamic DB, Filesytem & Web Watchdog, Sockets, API Server, Support You Fast Prototyping To Large Scale Systems

Installation / Usage
--------------------

To install use pip:

    $ pip install xo-gd


Or clone the repo:

    $ git clone https://github.com/fire17/xo-gd.git
    $ python setup.py install

Contributing
------------

TBD

Example
-------

TBD


